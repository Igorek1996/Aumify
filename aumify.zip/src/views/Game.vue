<template>
    <v-container fluid>
      <v-row>
        <v-col>
          <v-text-field
            v-model.number="sizeX"
            label="Size X"
            type="number"
            @change="drawGrid"
          ></v-text-field>
        </v-col>
        <v-col>
          <v-text-field
            v-model.number="sizeY"
            label="Size Y"
            type="number"
            @change="drawGrid"
          ></v-text-field>
        </v-col>
      </v-row>
      <div class="grid-container">
        <div
          v-for="(row, rowIndex) in grid"
          :key="rowIndex"
          class="grid-row"
        >
          <div
            v-for="(col, colIndex) in row"
            :key="colIndex"
            class="grid-item"
            :style="{ backgroundColor: col ? 'blue' : 'white' }"
            @mouseover="toggleColor(rowIndex, colIndex)"
          ></div>
        </div>
      </div>
    </v-container>
  </template>
  
  <script>
  import { ref, reactive } from 'vue';
  
  export default {
    setup() {
      const sizeX = ref(64);
      const sizeY = ref(64);
      const grid = reactive([]);
  
      const drawGrid = () => {
        grid.splice(0, grid.length);
        for (let i = 0; i < sizeY.value; i++) {
          grid.push(new Array(sizeX.value).fill(false));
        }
      };
  
      const toggleColor = (row, col) => {
        grid[row][col] = !grid[row][col];
      };
  
      drawGrid();
  
      return { sizeX, sizeY, grid, drawGrid, toggleColor };
    },
  };
  </script>
  
  <style scoped>
  .grid-container {
    display: flex;
    flex-direction: column;
  }
  
  .grid-row {
    display: flex;
  }
  
  .grid-item {
    width: 36px;
    height: 36px;
    border: 1px solid #333;
  }
  </style>
  