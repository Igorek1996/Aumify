<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" md="4">
        <v-card>
          <v-card-title>Login</v-card-title>
          <v-card-text>
            <v-form @submit.prevent="onSubmit">
              <v-text-field
                v-model="form.email"
                label="Email"
                :error-messages="emailErrors"
                prepend-icon="mdi-email"
              ></v-text-field>
              <v-text-field
                v-model="form.password"
                label="Password"
                type="password"
                :error-messages="passwordErrors"
                prepend-icon="mdi-lock"
              ></v-text-field>
              <v-btn
                type="submit"
                :disabled="v$.value.$invalid"
                color="primary"
              >
                Login
              </v-btn>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, computed } from "vue";
import { useRouter } from "vue-router";
import useVuelidate from "@vuelidate/core";
import { required, email, minLength } from "@vuelidate/validators";

const router = useRouter();
const form = ref({
  email: "",
  password: "",
});

const rules = {
  email: { required, email },
  password: { required, minLength: minLength(6) },
};

const v$ = useVuelidate(rules, form);

const onSubmit = () => {
  v$.value.$touch();
  if (!v$.value.$invalid) {
    router.push("/game");
  }
};

const emailErrors = computed(() => {
  const errors = [];
  if (!v$.value.email.$pending) {
    if (!v$.value.email.required) errors.push("Email is required.");
    if (!v$.value.email.email) errors.push("Must be a valid email.");
  }
  return errors;
});

const passwordErrors = computed(() => {
  const errors = [];
  if (!v$.value.password.$pending) {
    if (!v$.value.password.required) errors.push("Password is required.");
    if (!v$.value.password.minLength)
      errors.push("Password must be at least 6 characters.");
  }
  return errors;
});
</script>

<style scoped>
.v-card {
  padding: 20px;
}
</style>
